package org.um.ziga.lzprojekt

class predmetiDosezkov(val image: Int, val name: String, val opis: String)