package org.um.ziga.lzprojekt

import android.content.Context
import android.util.AttributeSet
import android.view.View
import java.util.jar.Attributes

class customToast(context: Context, attrs: AttributeSet) : View (context, attrs){




}